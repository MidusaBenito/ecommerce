from django.urls import path
from . import views

urlpatterns = [
    path('', views.store, name='store'),
    path('update_item/', views.updateItems, name='update_item'),
    path('cart/', views.cart, name='cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('process_order/', views.processOrder, name="process_order"),
    path('<slug:category_slug>/', views.store, name='sandle_list_by_category'),
    path('<int:id>/<slug:slug>/', views.sandle_detail, name='sandle_detail'),
    
]