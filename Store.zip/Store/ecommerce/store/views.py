from django.shortcuts import render, get_object_or_404
from .models import *
from django.http import JsonResponse
import json
import datetime
from . utils import cookieCart, cartData, guestOrder, get_sandles, men_sandles, ladies_sandles, kids_sandles
from datetime import datetime, timedelta

# Create your views here.
def store(request, category_slug=None):
    category=None
    data = cartData(request)
    cartItems = data['cartItems']
    
    sandles = get_sandles(request)
    #sandle_sizes = sizes(request)
    men = Category.objects.get(id=1).products.order_by('-created')
    ladies = Category.objects.get(id=2).products.order_by('-created')
    children = Category.objects.get(id=3).products.order_by('-created')
    men_sizes = men_sandles(request)
    ladies_sizes = ladies_sandles(request)
    kids_sizes = kids_sandles(request)
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        sandles = sandles.filter(category=category)
        #sandle_sizes = sandle_sizes.filter(category=category)
        #print(sandle_sizes)
    context = {"category": category,'sandles':sandles,'cartItems': cartItems,"men":men, "ladies":ladies, "children":children, "men_sizes":men_sizes, "ladies_sizes":ladies_sizes, "kids_sizes":kids_sizes}
    return render(request, 'store/store.html', context) 

#def sandle_sizes(request):

def sandle_detail(request, id, slug):
    data = cartData(request)
    #men_sizes=Category.objects.get(id=1).sizes.all()
    #ladies_sizes=Category.objects.get(id=2).sizes.all()
    #kids_sizes=Category.objects.get(id=3).sizes.all()
    cartItems = data['cartItems']
    sandle = get_object_or_404(Sandle, id=id, slug=slug)
    cat = (sandle.category)
    sizes = Category.objects.get(name=cat).sizes.order_by('-id')
    due_date = datetime.now() + timedelta(days=7)
    due_date_2 = datetime.now() + timedelta(days=10)
    context_bound = {'cartItems':cartItems,"sandle":sandle,"due_date":due_date, "due_date_2":due_date_2, "cat": cat, "sizes": sizes}
    return render(request, 
                    'store/detail.html', context_bound)

def cart(request):
    data = cartData(request)
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']
    context = {'items':items, 'order':order, 'cartItems':cartItems}
    return render(request, 'store/cart.html', context) 

def checkout(request):
    data = cartData(request)
    cartItems = data['cartItems']
    order = data['order']
    items = data['items']
    context = {'items':items, 'order':order, 'cartItems':cartItems}
    return render(request, 'store/checkout.html', context) 

def updateItems(request):
    data = json.loads(request.body)
    sandleId = data['sandleId']
    action = data['action']
    print('Action:', action)
    print('Sandle:',sandleId)

    customer = request.user.customer
    sandle = Sandle.objects.get(id=sandleId)
    order,created = Order.objects.get_or_create(customer=customer, complete=False)
    orderItem, created = OrderItem.objects.get_or_create(order=order, sandle=sandle)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity +1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)
    orderItem.save()
    if orderItem.quantity <= 0:
        orderItem.delete()
    return JsonResponse('Item was added', safe=False)

def processOrder(request):
    transaction_id = datetime.now().timestamp()
    data = json.loads(request.body)
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
        
    else:
        customer, order = guestOrder(request, data)
    total = float(data["form"]["total"])
    order.transaction_id = transaction_id
    print (total)

    if total == float(order.get_cart_total):
        order.complete = True
    order.save()
    if order.shipping == True:
        ShippingAddress.objects.create(
            customer=customer,
            order=order,
            address=data['shipping']['address'],
            town=data['shipping']['town'],
            county=data['shipping']['county'],
            )
    return JsonResponse('Payment complete!', safe=False)


